package com.xc.utils.sms.ali;

public class AliyunSmsConst {
  public static final String SIGN_NAME = "鸿鹄";
}
