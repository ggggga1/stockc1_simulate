package com.xc.dao;

import com.xc.pojo.AgentDistributionUser;

public interface AgentDistributionUserMapper {
    /**
     * [新增]
     * @author gg
     * @date 2020/05/31
     **/
    int insert(AgentDistributionUser agentDistributionUser);

    /**
     * [更新]
     * @author gg
     * @date 2020/05/31
     **/
    int update(AgentDistributionUser agentDistributionUser);
}
