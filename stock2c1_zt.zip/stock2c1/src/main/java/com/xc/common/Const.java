package com.xc.common;

public class Const {
  public static final String CURRENT_USER = "currentUser";
  
  public static void main(String[] args) {}
}

