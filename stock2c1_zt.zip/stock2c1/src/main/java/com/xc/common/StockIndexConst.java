package com.xc.common;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class StockIndexConst {
    //存储涨跌幅榜数据
    public final static Map<String,ServerResponse> ZDFBMap=new ConcurrentHashMap<>();
}

