package com.xc.common;

public class PayConst {}
